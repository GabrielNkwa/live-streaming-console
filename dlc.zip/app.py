from flask import Flask, render_template, request, redirect, Response
import cv2
import ultralytics
app = Flask(__name__)

cam = None


model = ultralytics.YOLO('yolo11n.pt') 
@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login', methods=['GET','POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    if username == 'admin' and password == 'admin':
        return render_template('index.html')
        #return render_template('player.html')
    else:
        return render_template('login.html', error='Invalid credentials')   
            
@app.route('/golive')
def video_feed():
    return Response(stream(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/goai')
def video_feedai():
    return Response(streamai(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

def doAI(img):
    res = model(img, verbose=False)
    rdata =res[0].boxes
    person =0
    cars = 0
    for d in rdata:
        cl = int(d.cls[0])
        conf = d.conf[0]
        x1 = int(d.xyxy[0][0])
        y1 = int(d.xyxy[0][1])
        x2 = int(d.xyxy[0][2])
        y2 = int(d.xyxy[0][3])
        img =cv2.rectangle(img, (x1,y1),(x2,y2),(0,255,0),2)
        if conf > 0.6:
            name = res[0].names[cl]
            cv2.putText(img,name,(x1, y1-10),cv2.FONT_HERSHEY_SIMPLEX, 0.6,(0,0,255),1)
            if name =='person':
                person +=1
            if name =='car' or name=='bus' or name=='truck':
                cars +=1
    if person > 0:
        print(f"Person: {person}, Vehicles: {cars}")
        analysis = f"Person: {person}, Vehicles: {cars}"
        
    cv2.putText(img, f'Person: {person}, Vehicles: {cars}', (10, 50), cv2.FONT_HERSHEY_COMPLEX,0.6,(0,0,0),2)
    return img

def streamai():
    global cam
    #cam = cv2.VideoCapture('rtsp://admin:admin@10.64.124.120:8554/streaming/live/1')
      # Use 0 for webcam or replace with RTMP URL
    capture = True
    while capture:
        try:
            # read the last frame from the RTMP stream
            
            ret, frame = cam.read()
            frame = doAI(frame)
            _, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        except Exception as e:
            print(f"Error: {e}")
            cam = cv2.VideoCapture(1)  # Use 0 for webcam or replace with RTMP URL
            capture = True
            

def stream():
    global cam
    #cam = cv2.VideoCapture('rtsp://admin:admin@10.64.124.120:8554/streaming/live/1')
    #cam = cv2.VideoCapture(0)  # Use 0 for webcam or replace with RTMP URL
    capture = True
    while capture:
        #print ("Camera = ", cam)
        try:
            # read the last frame from the RTMP stream
            
            ret, frame = cam.read()
            #frame = doAI(frame)
            _, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        except Exception as e:
            print(f"Error: {e}")
            cam = cv2.VideoCapture(1)  # Use 0 for webcam or replace with RTMP URL
            capture = True
            
if __name__ == '__main__':
    
    cam_path = input("Enter the Streaming Port (0, 1 or 2)")
    if cam_path=="0": cam_path=0
    if cam_path=="1": cam_path=1
    if cam_path=="2": cam_path=2
    cam = cv2.VideoCapture(cam_path)
    app.run('0.0.0.0')